using Microsoft.EntityFrameworkCore;

public class MiscDbContext : DbContext
{
    public MiscDbContext(DbContextOptions<MiscDbContext> options) : base(options)
    {

    }
}