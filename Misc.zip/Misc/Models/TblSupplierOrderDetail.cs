﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class TblSupplierOrderDetail
{
    public int DetailId { get; set; }

    public int? OrderId { get; set; }

    public int? PartId { get; set; }

    /// <summary>
    /// frozen
    /// </summary>
    public int? QtyOnOrigOrder { get; set; }

    public int? QtyToPost { get; set; }

    public int? QtyAlreadyPosted { get; set; }

    public DateTime? ExpectedDate { get; set; }

    /// <summary>
    /// jr: Short Text (255 characters) prob OK
    /// </summary>
    public string? Comment { get; set; }

    public virtual TblSupplierOrderHdr? Order { get; set; }

    public virtual TblPartMaster? Part { get; set; }
}
