﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class TblSupplierOrderHdr
{
    public int OrderId { get; set; }

    public int? SupplierId { get; set; }

    public DateTime? OrderDate { get; set; }

    public bool? IsProcessedSupplierOrderEntry { get; set; }

    public bool? IsProcessedReceived { get; set; }

    /// <summary>
    /// this will store the complete PO, ex. CA5004
    /// </summary>
    public string? Po { get; set; }

    public string? SpecialInstructions { get; set; }

    /// <summary>
    /// jr added 07/15
    /// </summary>
    public decimal? ExtraCharges { get; set; }

    /// <summary>
    /// jr added 07/15
    /// </summary>
    public string? ExtraChargesReason { get; set; }

    public byte[] SsmaTimeStamp { get; set; } = null!;

    public virtual TblSupplier? Supplier { get; set; }

    public virtual ICollection<TblOrderHistory> TblOrderHistories { get; set; } = new List<TblOrderHistory>();

    public virtual ICollection<TblReceiptHistory> TblReceiptHistories { get; set; } = new List<TblReceiptHistory>();

    public virtual ICollection<TblSupplierOrderDetail> TblSupplierOrderDetails { get; set; } = new List<TblSupplierOrderDetail>();
}
