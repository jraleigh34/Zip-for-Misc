﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class TblPartMaster
{
    public int PartId { get; set; }

    public string? PartNumber { get; set; }

    public string? Description { get; set; }

    /// <summary>
    /// data entry by picklist
    /// </summary>
    public string? Category { get; set; }

    public decimal? UnitCost { get; set; }

    public int? QtyOnHand { get; set; }

    public int? QtyOnOrder { get; set; }

    public int? QtyToReduce { get; set; }

    public DateTime? DateReduced { get; set; }

    public int? ReOrderLevel { get; set; }

    public string? Comments { get; set; }

    /// <summary>
    /// ex. 23&quot;x16&quot;x16&quot;
    /// </summary>
    public string? Size { get; set; }

    public byte[] SsmaTimeStamp { get; set; } = null!;

    public virtual ICollection<TblSupplierOrderDetail> TblSupplierOrderDetails { get; set; } = new List<TblSupplierOrderDetail>();
}
