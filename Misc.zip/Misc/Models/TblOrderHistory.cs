﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class TblOrderHistory
{
    public int HistoryId { get; set; }

    public DateTime? HistoryDate { get; set; }

    public string? Po { get; set; }

    public string? Supplier { get; set; }

    public int? OrderId { get; set; }

    public string? PartNumber { get; set; }

    public string? Description { get; set; }

    public decimal? Price { get; set; }

    public int? QtyOnOrigOrder { get; set; }

    public int? QtyToPost { get; set; }

    public int? QtyAlreadyPosted { get; set; }

    public DateTime? ExpectedDate { get; set; }

    public string? Comment { get; set; }

    public virtual TblSupplierOrderHdr? Order { get; set; }
}
