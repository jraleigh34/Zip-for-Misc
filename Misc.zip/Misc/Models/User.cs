﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class User
{
    public int UserId { get; set; }

    public string? ShortName { get; set; }

    public string? FullName { get; set; }

    public string? Initials { get; set; }

    public string? Email { get; set; }

    public string? Reminder { get; set; }

    public byte[] SsmaTimeStamp { get; set; } = null!;
}
