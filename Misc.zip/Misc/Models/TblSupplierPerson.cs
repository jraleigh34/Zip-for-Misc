﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class TblSupplierPerson
{
    public int SupplierPersonId { get; set; }

    public int? SupplierId { get; set; }

    public string? ContactName { get; set; }

    public string Email { get; set; } = null!;

    public string? TelNo1 { get; set; }

    public string? TelNo2 { get; set; }

    public string? FaxNo { get; set; }

    public string? PersonNotes { get; set; }

    public bool? DefaultEmailRecipient { get; set; }

    public byte[] SsmaTimeStamp { get; set; } = null!;

    public virtual TblSupplier? Supplier { get; set; }
}
