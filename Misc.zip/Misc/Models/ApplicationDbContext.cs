﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Misc.Models;

public partial class ApplicationDbContext : DbContext
{
    public ApplicationDbContext()
    {
    }

    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public virtual DbSet<TblInventoryReductionHistory> TblInventoryReductionHistories { get; set; }

    public virtual DbSet<TblOrderHistory> TblOrderHistories { get; set; }

    public virtual DbSet<TblPartMaster> TblPartMasters { get; set; }

    public virtual DbSet<TblReceiptHistory> TblReceiptHistories { get; set; }

    public virtual DbSet<TblSupplier> TblSuppliers { get; set; }

    public virtual DbSet<TblSupplierOrderDetail> TblSupplierOrderDetails { get; set; }

    public virtual DbSet<TblSupplierOrderHdr> TblSupplierOrderHdrs { get; set; }

    public virtual DbSet<TblSupplierPerson> TblSupplierPeople { get; set; }

    public virtual DbSet<TblSystemvalue> TblSystemvalues { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public virtual DbSet<ZtblProductCategory> ZtblProductCategories { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Server=.\\mssqlserver02; Database=Misc;Trusted_Connection=True;MultipleActiveResultSets=true; TrustServerCertificate=true;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TblInventoryReductionHistory>(entity =>
        {
            entity.HasKey(e => e.HistoryId).HasName("tblInventoryReductionHistory$PrimaryKey");

            entity.ToTable("tblInventoryReductionHistory");

            entity.HasIndex(e => e.HistoryId, "tblInventoryReductionHistory$HistoryID");

            entity.Property(e => e.HistoryId).HasColumnName("HistoryID");
            entity.Property(e => e.Comment).HasMaxLength(255);
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.HistoryDate).HasPrecision(0);
            entity.Property(e => e.PartNumber).HasMaxLength(255);
            entity.Property(e => e.QtyOnHand).HasDefaultValue(0);
            entity.Property(e => e.QtyToReduce).HasDefaultValue(0);
        });

        modelBuilder.Entity<TblOrderHistory>(entity =>
        {
            entity.HasKey(e => e.HistoryId).HasName("tblOrderHistory$PrimaryKey");

            entity.ToTable("tblOrderHistory");

            entity.HasIndex(e => e.HistoryId, "tblOrderHistory$HistoryID");

            entity.HasIndex(e => e.OrderId, "tblOrderHistory$OrderID");

            entity.Property(e => e.HistoryId).HasColumnName("HistoryID");
            entity.Property(e => e.Comment).HasMaxLength(255);
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ExpectedDate).HasPrecision(0);
            entity.Property(e => e.HistoryDate).HasPrecision(0);
            entity.Property(e => e.OrderId).HasColumnName("OrderID");
            entity.Property(e => e.PartNumber).HasMaxLength(255);
            entity.Property(e => e.Po)
                .HasMaxLength(255)
                .HasColumnName("PO");
            entity.Property(e => e.Price)
                .HasDefaultValue(0m)
                .HasColumnType("money");
            entity.Property(e => e.QtyOnOrigOrder).HasDefaultValue(0);
            entity.Property(e => e.QtyToPost).HasDefaultValue(0);
            entity.Property(e => e.Supplier).HasMaxLength(255);

            entity.HasOne(d => d.Order).WithMany(p => p.TblOrderHistories)
                .HasForeignKey(d => d.OrderId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("tblOrderHistory$tblSupplierOrder_hdrtblOrderHistory");
        });

        modelBuilder.Entity<TblPartMaster>(entity =>
        {
            entity.HasKey(e => e.PartId).HasName("tblPartMaster$PrimaryKey");

            entity.ToTable("tblPartMaster");

            entity.HasIndex(e => e.PartNumber, "tblPartMaster$PartNumberIX").IsUnique();

            entity.Property(e => e.PartId).HasColumnName("PartID");
            entity.Property(e => e.Category)
                .HasMaxLength(255)
                .HasComment("data entry by picklist");
            entity.Property(e => e.DateReduced).HasPrecision(0);
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.PartNumber).HasMaxLength(255);
            entity.Property(e => e.QtyOnHand).HasDefaultValue(0);
            entity.Property(e => e.QtyOnOrder).HasDefaultValue(0);
            entity.Property(e => e.QtyToReduce).HasDefaultValue(0);
            entity.Property(e => e.ReOrderLevel).HasDefaultValue(0);
            entity.Property(e => e.Size)
                .HasMaxLength(255)
                .HasComment("ex. 23\"x16\"x16\"");
            entity.Property(e => e.SsmaTimeStamp)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("SSMA_TimeStamp");
            entity.Property(e => e.UnitCost)
                .HasDefaultValue(0m)
                .HasColumnType("money");
        });

        modelBuilder.Entity<TblReceiptHistory>(entity =>
        {
            entity.HasKey(e => e.HistoryId).HasName("tblReceiptHistory$PrimaryKey");

            entity.ToTable("tblReceiptHistory");

            entity.HasIndex(e => e.HistoryId, "tblReceiptHistory$HistoryID");

            entity.HasIndex(e => e.OrderId, "tblReceiptHistory$OrderID");

            entity.Property(e => e.HistoryId).HasColumnName("HistoryID");
            entity.Property(e => e.Comment).HasMaxLength(255);
            entity.Property(e => e.Description).HasMaxLength(255);
            entity.Property(e => e.ExpectedDate).HasPrecision(0);
            entity.Property(e => e.HistoryDate).HasPrecision(0);
            entity.Property(e => e.OrderId).HasColumnName("OrderID");
            entity.Property(e => e.PartNumber).HasMaxLength(255);
            entity.Property(e => e.Po)
                .HasMaxLength(255)
                .HasColumnName("PO");
            entity.Property(e => e.Price)
                .HasDefaultValue(0m)
                .HasColumnType("money");
            entity.Property(e => e.QtyOnHand).HasDefaultValue(0);
            entity.Property(e => e.QtyOnOrder).HasDefaultValue(0);
            entity.Property(e => e.QtyOnOrigOrder).HasDefaultValue(0);
            entity.Property(e => e.QtyToRecv).HasDefaultValue(0);
            entity.Property(e => e.Supplier).HasMaxLength(255);

            entity.HasOne(d => d.Order).WithMany(p => p.TblReceiptHistories)
                .HasForeignKey(d => d.OrderId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("tblReceiptHistory$tblSupplierOrder_hdrtblReceiptHistory");
        });

        modelBuilder.Entity<TblSupplier>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("tblSupplier$ID");

            entity.ToTable("tblSupplier");

            entity.Property(e => e.Id).HasColumnName("ID");
            entity.Property(e => e.Address1).HasMaxLength(50);
            entity.Property(e => e.Address2).HasMaxLength(50);
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.Contact).HasMaxLength(255);
            entity.Property(e => e.Email).HasMaxLength(255);
            entity.Property(e => e.Phone).HasMaxLength(50);
            entity.Property(e => e.St).HasMaxLength(50);
            entity.Property(e => e.SupplierName).HasMaxLength(255);
            entity.Property(e => e.Zip).HasMaxLength(50);
        });

        modelBuilder.Entity<TblSupplierOrderDetail>(entity =>
        {
            entity.HasKey(e => e.DetailId).HasName("tblSupplierOrder_detail$PrimaryKey");

            entity.ToTable("tblSupplierOrder_detail");

            entity.HasIndex(e => e.DetailId, "tblSupplierOrder_detail$DetailID");

            entity.HasIndex(e => e.OrderId, "tblSupplierOrder_detail$OrderID");

            entity.HasIndex(e => e.PartId, "tblSupplierOrder_detail$PartID");

            entity.Property(e => e.DetailId).HasColumnName("DetailID");
            entity.Property(e => e.Comment)
                .HasMaxLength(255)
                .HasComment("jr: Short Text (255 characters) prob OK");
            entity.Property(e => e.ExpectedDate).HasPrecision(0);
            entity.Property(e => e.OrderId).HasColumnName("OrderID");
            entity.Property(e => e.PartId).HasColumnName("PartID");
            entity.Property(e => e.QtyAlreadyPosted).HasDefaultValue(0);
            entity.Property(e => e.QtyOnOrigOrder)
                .HasDefaultValue(0)
                .HasComment("frozen");
            entity.Property(e => e.QtyToPost).HasDefaultValue(0);

            entity.HasOne(d => d.Order).WithMany(p => p.TblSupplierOrderDetails)
                .HasForeignKey(d => d.OrderId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("tblSupplierOrder_detail$tblSupplierOrder_hdrtblSupplierOrder_detail");

            entity.HasOne(d => d.Part).WithMany(p => p.TblSupplierOrderDetails)
                .HasForeignKey(d => d.PartId)
                .HasConstraintName("tblSupplierOrder_detail$tblPartMastertblSupplierOrder_detail");
        });

        modelBuilder.Entity<TblSupplierOrderHdr>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("tblSupplierOrder_hdr$PrimaryKey");

            entity.ToTable("tblSupplierOrder_hdr");

            entity.HasIndex(e => e.OrderId, "tblSupplierOrder_hdr$OrderID");

            entity.HasIndex(e => e.SupplierId, "tblSupplierOrder_hdr$SupplierID");

            entity.Property(e => e.OrderId).HasColumnName("OrderID");
            entity.Property(e => e.ExtraCharges)
                .HasDefaultValue(0m)
                .HasComment("jr added 07/15")
                .HasColumnType("money");
            entity.Property(e => e.ExtraChargesReason)
                .HasMaxLength(255)
                .HasComment("jr added 07/15");
            entity.Property(e => e.IsProcessedReceived)
                .HasDefaultValue(false)
                .HasColumnName("IsProcessed_Received");
            entity.Property(e => e.IsProcessedSupplierOrderEntry)
                .HasDefaultValue(false)
                .HasColumnName("IsProcessed_SupplierOrderEntry");
            entity.Property(e => e.OrderDate).HasPrecision(0);
            entity.Property(e => e.Po)
                .HasMaxLength(255)
                .HasComment("this will store the complete PO, ex. CA5004")
                .HasColumnName("PO");
            entity.Property(e => e.SsmaTimeStamp)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("SSMA_TimeStamp");
            entity.Property(e => e.SupplierId).HasColumnName("SupplierID");

            entity.HasOne(d => d.Supplier).WithMany(p => p.TblSupplierOrderHdrs)
                .HasForeignKey(d => d.SupplierId)
                .OnDelete(DeleteBehavior.Cascade)
                .HasConstraintName("tblSupplierOrder_hdr$tblSuppliertblSupplierOrder_hdr");
        });

        modelBuilder.Entity<TblSupplierPerson>(entity =>
        {
            entity.HasKey(e => e.SupplierPersonId).HasName("tblSupplierPeople$PrimaryKey");

            entity.ToTable("tblSupplierPeople");

            entity.HasIndex(e => e.SupplierId, "tblSupplierPeople$CustomerID");

            entity.HasIndex(e => e.SupplierPersonId, "tblSupplierPeople$SuppierPersonID");

            entity.Property(e => e.SupplierPersonId).HasColumnName("SupplierPersonID");
            entity.Property(e => e.ContactName).HasMaxLength(255);
            entity.Property(e => e.DefaultEmailRecipient).HasDefaultValue(false);
            entity.Property(e => e.Email).HasMaxLength(255);
            entity.Property(e => e.FaxNo).HasMaxLength(255);
            entity.Property(e => e.PersonNotes).HasMaxLength(255);
            entity.Property(e => e.SsmaTimeStamp)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("SSMA_TimeStamp");
            entity.Property(e => e.SupplierId).HasColumnName("SupplierID");
            entity.Property(e => e.TelNo1).HasMaxLength(255);
            entity.Property(e => e.TelNo2).HasMaxLength(255);

            entity.HasOne(d => d.Supplier).WithMany(p => p.TblSupplierPeople)
                .HasForeignKey(d => d.SupplierId)
                .HasConstraintName("tblSupplierPeople$tblSuppliertblSupplierPeople");
        });

        modelBuilder.Entity<TblSystemvalue>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("tblSYSTEMVALUES");

            entity.Property(e => e.Address1).HasMaxLength(50);
            entity.Property(e => e.Address2).HasMaxLength(50);
            entity.Property(e => e.City).HasMaxLength(50);
            entity.Property(e => e.Contact).HasMaxLength(50);
            entity.Property(e => e.ExportPath).HasMaxLength(100);
            entity.Property(e => e.Fax).HasMaxLength(50);
            entity.Property(e => e.OrgName)
                .HasMaxLength(50)
                .HasComment("This  user-accessible table has organization-level  data that may change from time-to time.");
            entity.Property(e => e.Phone).HasMaxLength(50);
            entity.Property(e => e.PofolderPath)
                .HasMaxLength(255)
                .HasColumnName("POFolderPath");
            entity.Property(e => e.St).HasMaxLength(50);
            entity.Property(e => e.Zip).HasMaxLength(50);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("Users$PrimaryKey");

            entity.HasIndex(e => e.UserId, "Users$UserID");

            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Email).HasMaxLength(255);
            entity.Property(e => e.FullName).HasMaxLength(255);
            entity.Property(e => e.Initials).HasMaxLength(255);
            entity.Property(e => e.ShortName).HasMaxLength(255);
            entity.Property(e => e.SsmaTimeStamp)
                .IsRowVersion()
                .IsConcurrencyToken()
                .HasColumnName("SSMA_TimeStamp");
        });

        modelBuilder.Entity<ZtblProductCategory>(entity =>
        {
            entity.HasKey(e => e.Desc).HasName("ztblProductCategory$PrimaryKey");

            entity.ToTable("ztblProductCategory");

            entity.Property(e => e.Desc).HasMaxLength(255);
            entity.Property(e => e.Sort).HasDefaultValue(0);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
