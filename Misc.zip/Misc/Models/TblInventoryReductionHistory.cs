﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class TblInventoryReductionHistory
{
    public int HistoryId { get; set; }

    public DateTime? HistoryDate { get; set; }

    public string? PartNumber { get; set; }

    public string? Description { get; set; }

    public int? QtyOnHand { get; set; }

    public int? QtyToReduce { get; set; }

    public string? Comment { get; set; }
}
