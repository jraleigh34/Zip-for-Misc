﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class TblSystemvalue
{
    /// <summary>
    /// This  user-accessible table has organization-level  data that may change from time-to time.
    /// </summary>
    public string? OrgName { get; set; }

    public string? ExportPath { get; set; }

    public string? PofolderPath { get; set; }

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public string? City { get; set; }

    public string? St { get; set; }

    public string? Zip { get; set; }

    public string? Phone { get; set; }

    public string? Fax { get; set; }

    public string? Contact { get; set; }
}
