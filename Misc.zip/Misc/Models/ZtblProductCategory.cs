﻿using System;
using System.Collections.Generic;

namespace Misc.Models;

public partial class ZtblProductCategory
{
    public string Desc { get; set; } = null!;

    public int? Sort { get; set; }
}
